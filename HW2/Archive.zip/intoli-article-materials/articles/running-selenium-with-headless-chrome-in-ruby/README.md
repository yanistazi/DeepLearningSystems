# Running Selenium with Headless Chrome in Ruby

[Running Selenium with Headless Chrome in Ruby](view-source:https://intoli.com/blog/running-selenium-with-headless-chrome-in-ruby/) demonstrates how to use headless Chrome in Ruby with Selenium.

- [take-screenshot.rb](take-screenshot.rb) - A simple script to launch headless Chrome and save a screenshot.
