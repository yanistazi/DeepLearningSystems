# How to Clear the Chrome Browser Cache With Selenium WebDriver/ChromeDriver

[How to Clear the Chrome Browser Cache With Selenium WebDriver/ChromeDriver](https://intoli.com/blog/clear-the-chrome-browser-cache/) develops a method to clear the Chrome browser cache in Selenium.

- [clear_chrome_cache.py](clear_chrome_cache.py) - Defines the `clear_cache()` method.
