# Email Spy

[Email Spy](https://intoli.com/blog/email-spy/) is an open source browser extension that we developed for finding contact emails for various domains as you browse.
This one was large enough to get it's own repository--so there aren't any supplementary materials--but you check out the full source code [here](https://github.com/sangaline/email-spy).
